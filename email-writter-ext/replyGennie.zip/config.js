// config.js
const BACKEND_URL = "https://email-writer-app-1234-degpdacahpg5b4gy.centralindia-01.azurewebsites.net";
